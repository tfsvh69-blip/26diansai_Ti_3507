/**
 ****************************************************************************************************
 * @file        demo.c
 * @author      ����ԭ���Ŷ�(ALIENTEK)
 * @version     V1.0
 * @date        2022-06-21
 * @brief       ATK-MS6DSVģ�����ʵ��
 * @license     Copyright (c) 2020-2032, �������������ӿƼ����޹�˾
 ****************************************************************************************************
 * @attention
 *
 * ʵ��ƽ̨:����ԭ�� MiniSTM32 V4������
 * ������Ƶ:www.yuanzige.com
 * ������̳:www.openedv.com
 * ��˾��ַ:www.alientek.com
 * �����ַ:openedv.taobao.com
 *
 ****************************************************************************************************
 */

#include "demo.h"
#include "./BSP/ATK_MS6DSV/atk_ms6dsv.h"
#include "./SYSTEM/usart/usart.h"
#include "./SYSTEM/delay/delay.h"
#include "./BSP/LED/led.h"

#define DEMO_READ_DATA_POLLING      /* ��ѯ��ȡ���ٶȡ����ٶȺ��¶����� */
//#define DEMO_READ_DATA_FIFO_POLLING /* ��ѯ��ȡFIFO�еļ��ٶȡ����ٶȺ�ʱ������� */
//#define DEMO_QVAR_READ_DATA_POLLING /* ��ѯ��ȡ�����ѹ���� */
//#define DEMO_READ_DATA_INT          /* �ж϶�ȡ���ٶ����� */
//#define DEMO_READ_DATA_FIFO_INT     /* �ж϶�ȡFIFO�еļ��ٶȺ�ʱ������� */
//#define DEMO_FREE_FALL              /* �ж϶�ȡ��������״̬ */
//#define DEMO_WAKEUP                 /* �ж϶�ȡ����״̬ */
//#define DEMO_6D                     /* �ж϶�ȡ6D����״̬ */
//#define DEMO_TAP                    /* �ж϶�ȡ������˫��ʶ��״̬ */
//#define DEMO_STEP_COUNTER           /* ������⹦�� */
//#define DEMO_SENSOR_FUSION          /* �������ںϹ��� */
//#define DEMO_SENSOR_FUSION_ANOTC    /* �������ںϹ����ϴ�������λ�� */
//#define DEMO_FSM_TOUCH              /* ״̬�����紥����⹦�� */
//#define DEMO_FSM_4D                 /* ״̬��4D�����⹦�� */

#ifdef DEMO_FSM_TOUCH
#include "./BSP/ATK_MS6DSV/lsm6dsv16x_fsm_touch.h"
#endif /* DEMO_FSM_TOUCH */
#ifdef DEMO_FSM_4D
#include "./BSP/ATK_MS6DSV/lsm6dsv16x_four_d.h"
#endif /* DEMO_FSM_4D */

#if defined(DEMO_SENSOR_FUSION) || defined(DEMO_SENSOR_FUSION_ANOTC)
static uint32_t npy_halfbits_to_floatbits(uint16_t h)
{
    uint16_t h_exp, h_sig;
    uint32_t f_sgn, f_exp, f_sig;

    h_exp = (h&0x7c00u);
    f_sgn = ((uint32_t)h&0x8000u) << 16;
    switch (h_exp) {
        case 0x0000u: /* 0 or subnormal */
            h_sig = (h&0x03ffu);
            /* Signed zero */
            if (h_sig == 0) {
                return f_sgn;
            }
            /* Subnormal */
            h_sig <<= 1;
            while ((h_sig&0x0400u) == 0) {
                h_sig <<= 1;
                h_exp++;
            }
            f_exp = ((uint32_t)(127 - 15 - h_exp)) << 23;
            f_sig = ((uint32_t)(h_sig&0x03ffu)) << 13;
            return f_sgn + f_exp + f_sig;
        case 0x7c00u: /* inf or NaN */
            /* All-ones exponent and a copy of the significand */
            return f_sgn + 0x7f800000u + (((uint32_t)(h&0x03ffu)) << 13);
        default: /* normalized */
            /* Just need to adjust the exponent and shift */
            return f_sgn + (((uint32_t)(h&0x7fffu) + 0x1c000u) << 13);
    }
}

static float_t npy_half_to_float(uint16_t h)
{
    union { float_t ret; uint32_t retbits; } conv;
    conv.retbits = npy_halfbits_to_floatbits(h);
    return conv.ret;
}

static void sflp2q(float quat[4], uint16_t sflp[3])
{
    float sumsq = 0;

    quat[0] = npy_half_to_float(sflp[0]);
    quat[1] = npy_half_to_float(sflp[1]);
    quat[2] = npy_half_to_float(sflp[2]);

    for (uint8_t i = 0; i < 3; i++)
    sumsq += quat[i] * quat[i];

    if (sumsq > 1.0f) {
        float n = sqrtf(sumsq);
        quat[0] /= n;
        quat[1] /= n;
        quat[2] /= n;
        sumsq = 1.0f;
    }

    quat[3] = sqrtf(1.0f - sumsq);
}
#endif /* DEMO_SENSOR_FUSION or DEMO_SENSOR_FUSION_ANOTC */
#ifdef DEMO_SENSOR_FUSION_ANOTC


/**
 * @brief       ͨ������1������������������վV4
 * @param       fun: ������
 *              dat: �����͵����ݣ����28�ֽڣ�
 *              len: dat���ݵ���Чλ��
 * @retval      ��
 */
static void demo_usart1_niming_report(uint8_t fun, uint8_t *dat, uint8_t len)
{
    uint8_t send_buf[32];
    uint8_t i;
    
    if (len > 28)
    {
        return;
    }
    
    send_buf[len+4] = 0;            /* У��λ���� */
    send_buf[0] = 0xAA;             /* ֡ͷΪ0xAAAA */
    send_buf[1] = 0xAA;             /* ֡ͷΪ0xAAAA */
    send_buf[2] = fun;              /* ������ */
    send_buf[3] = len;              /* ���ݳ��� */
    for (i=0; i<len; i++)           /* �������� */
    {
        send_buf[4 + i] = dat[i];
    }
    for (i=0; i<(len + 4); i++)     /* ����У��� */
    {
        send_buf[len + 4] += send_buf[i];
    }
    
    /* �������� */
    HAL_UART_Transmit(&g_uart1_handle, send_buf, len + 5, HAL_MAX_DELAY);
}

/**
 * @brief       ����״̬֡����������վV4
 * @param       rol     : �����
 *              pit     : ������
 *              yaw     : �����
 *              alt     : ���и߶ȣ���λ��cm
 *              fly_mode: ����ģʽ
 *              armed   : ����״̬��0xA0������ 0xA1������
 * @retval      ��
 */
static void demo_niming_report_status(int16_t rol, int16_t pit, int16_t yaw, uint32_t alt, uint8_t fly_mode, uint8_t armed)
{
    uint8_t send_buf[12];
    
    /* ����� */
    send_buf[0] = (rol >> 8) & 0xFF;
    send_buf[1] = rol & 0xFF;
    /* ������ */
    send_buf[2] = (pit >> 8) & 0xFF;
    send_buf[3] = pit & 0xFF;
    /* ����� */
    send_buf[4] = (yaw >> 8) & 0xFF;
    send_buf[5] = yaw & 0xFF;
    /* ���и߶� */
    send_buf[6] = (alt >> 24) & 0xFF;
    send_buf[7] = (alt >> 16) & 0xFF;
    send_buf[8] = (alt >> 8) & 0xFF;
    send_buf[9] = alt & 0xFF;
    /* ����ģʽ */
    send_buf[10] = fly_mode;
    /* ����״̬ */
    send_buf[11] = armed;
    
    /* ״̬֡�Ĺ�����Ϊ0x01 */
    demo_usart1_niming_report(0x01, send_buf, 12);
}
#endif /* DEMO_SENSOR_FUSION_ANOTC */

/**
 * @brief       ������ʾ��ں���
 * @param       ��
 * @retval      ��
 */
void demo_run(void)
{
    uint8_t ret;
#ifdef DEMO_READ_DATA_POLLING
    lsm6dsv16x_filt_settling_mask_t filt_settling_mask;
    lsm6dsv16x_data_ready_t drdy;
    int16_t data_raw_acceleration[3];
    int16_t data_raw_angular_rate[3];
    int16_t data_raw_temperature;
    float acceleration_mg[3];
    float angular_rate_mdps[3];
    float temperature_degc;
    uint8_t times = 0;
#endif /* DEMO_READ_DATA_POLLING */
#ifdef DEMO_READ_DATA_FIFO_POLLING
    lsm6dsv16x_fifo_status_t fifo_status;
    lsm6dsv16x_fifo_out_raw_t data_raw_fifo;
    int16_t *datax;
    int16_t *datay;
    int16_t *dataz;
    int32_t *ts;
    float acceleration_mg[3];
    float angular_rate_mdps[3];
    int32_t timestamp;
    uint8_t times = 0;
#endif /* DEMO_READ_DATA_FIFO_POLLING */
#ifdef DEMO_QVAR_READ_DATA_POLLING
    lsm6dsv16x_filt_settling_mask_t filt_settling_mask;
    lsm6dsv16x_ah_qvar_mode_t qvar_mode;
    lsm6dsv16x_all_sources_t all_sources;
    int16_t data_raw_qvar;
    float qvar_mv;
    uint8_t times = 0;
#endif /* DEMO_QVAR_READ_DATA_POLLING */
#ifdef DEMO_READ_DATA_INT
    lsm6dsv16x_pin_int_route_t pin_int;
    lsm6dsv16x_filt_settling_mask_t filt_settling_mask;
    lsm6dsv16x_data_ready_t drdy;
    int16_t data_raw_acceleration[3];
    float acceleration_mg[3];
    uint8_t times = 0;
#endif /* DEMO_READ_DATA_INT */
#ifdef DEMO_READ_DATA_FIFO_INT
    lsm6dsv16x_pin_int_route_t pin_int;
    lsm6dsv16x_fifo_status_t fifo_status;
    uint16_t num;
    lsm6dsv16x_fifo_out_raw_t data_raw_fifo;
    int16_t *datax;
    int16_t *datay;
    int16_t *dataz;
    int32_t *ts;
    float acceleration_mg[3];
    int32_t timestamp;
    uint8_t times = 0;
#endif /* DEMO_READ_DATA_FIFO_INT */
#ifdef DEMO_FREE_FALL
    lsm6dsv16x_pin_int_route_t pin_int;
    lsm6dsv16x_interrupt_mode_t irq;
    lsm6dsv16x_all_sources_t status;
#endif /* DEMO_FREE_FALL */
#ifdef DEMO_WAKEUP
    lsm6dsv16x_pin_int_route_t pin_int;
    lsm6dsv16x_interrupt_mode_t irq;
    lsm6dsv16x_act_thresholds_t wu;
    lsm6dsv16x_all_sources_t status;
#endif /* DEMO_WAKEUP */
#ifdef DEMO_6D
    lsm6dsv16x_pin_int_route_t pin_int;
    lsm6dsv16x_interrupt_mode_t irq;
    lsm6dsv16x_all_sources_t status;
    uint8_t sixd_event;
#endif /* DEMO_6D */
#ifdef DEMO_TAP
    lsm6dsv16x_pin_int_route_t pin_int;
    lsm6dsv16x_interrupt_mode_t irq;
    lsm6dsv16x_tap_detection_t tap;
    lsm6dsv16x_tap_thresholds_t tap_ths;
    lsm6dsv16x_tap_time_windows_t tap_win;
    lsm6dsv16x_all_sources_t status;
#endif /* DEMO_TAP */
#ifdef DEMO_STEP_COUNTER
    lsm6dsv16x_filt_settling_mask_t filt_settling_mask;
    lsm6dsv16x_stpcnt_mode_t stpcnt_mode;
    lsm6dsv16x_all_sources_t status;
    uint16_t steps;
#endif /* DEMO_STEP_COUNTER */
#ifdef DEMO_SENSOR_FUSION
    lsm6dsv16x_fifo_sflp_raw_t fifo_sflp;
    lsm6dsv16x_sflp_gbias_t gbias;
    lsm6dsv16x_fifo_status_t fifo_status;
    uint16_t num;
    lsm6dsv16x_fifo_out_raw_t data_raw_fifo;
    int16_t *axis;
    float quat[4];
    float gravity_mg[3];
    float gbias_mdps[3];
    uint8_t times = 0;
#endif /* DEMO_SENSOR_FUSION */
#ifdef DEMO_SENSOR_FUSION_ANOTC
    lsm6dsv16x_fifo_sflp_raw_t fifo_sflp;
    lsm6dsv16x_fifo_status_t fifo_status;
    uint16_t num;
    lsm6dsv16x_fifo_out_raw_t data_raw_fifo;
    lsm6dsv16x_data_ready_t drdy;
    int16_t data_raw_angular_rate[3];
    float angular_rate_mdps_avg[3] = {0};
    uint32_t times;
    lsm6dsv16x_sflp_gbias_t gbias;
    float quat[4];
    float pitch;
    float roll;
    float yaw;
#endif /* DEMO_SENSOR_FUSION_ANOTC */
#ifdef DEMO_FSM_TOUCH
    lsm6dsv16x_filt_settling_mask_t filt_settling_mask;
    lsm6dsv16x_ah_qvar_mode_t qvar_mode;
    uint32_t reg_index;
    lsm6dsv16x_fsm_status_mainpage_t fsm_status;
#endif /* DEMO_FSM_TOUCH */
#ifdef DEMO_FSM_4D
    lsm6dsv16x_filt_settling_mask_t filt_settling_mask;
    uint32_t reg_index;
    lsm6dsv16x_fsm_status_mainpage_t fsm_status;
    lsm6dsv16x_fsm_out_t fsm_out;
#endif /* DEMO_FSM_4D */
    
    /* ��ʼ��ATK-MS6DSVģ�� */
    ret = atk_ms6dsv_init();
    if (ret != 0)
    {
        printf("ATK-MS6DSV init failed!\r\n");
        while (1)
        {
            LED0_TOGGLE();
            delay_ms(200);
        }
    }
    
#ifdef DEMO_READ_DATA_POLLING
    /* ���ü��ٶȼƺ������ǵ�ODR */
    lsm6dsv16x_xl_data_rate_set(&atk_ms6dsv, LSM6DSV16X_ODR_AT_60Hz);
    lsm6dsv16x_gy_data_rate_set(&atk_ms6dsv, LSM6DSV16X_ODR_AT_60Hz);
    
    /* ���ü��ٶȼƺ������ǵ����� */
    lsm6dsv16x_xl_full_scale_set(&atk_ms6dsv, LSM6DSV16X_2g);
    lsm6dsv16x_gy_full_scale_set(&atk_ms6dsv, LSM6DSV16X_2000dps);
    
    /* �����˲��� */
    filt_settling_mask.drdy = PROPERTY_ENABLE;
    filt_settling_mask.irq_xl = PROPERTY_ENABLE;
    filt_settling_mask.irq_g = PROPERTY_ENABLE;
    lsm6dsv16x_filt_settling_mask_set(&atk_ms6dsv, filt_settling_mask);
    lsm6dsv16x_filt_gy_lp1_set(&atk_ms6dsv, PROPERTY_ENABLE);
    lsm6dsv16x_filt_gy_lp1_bandwidth_set(&atk_ms6dsv, LSM6DSV16X_GY_ULTRA_LIGHT);
    lsm6dsv16x_filt_xl_lp2_set(&atk_ms6dsv, PROPERTY_ENABLE);
    lsm6dsv16x_filt_xl_lp2_bandwidth_set(&atk_ms6dsv, LSM6DSV16X_XL_STRONG);
    
    while (1)
    {
        /* ��ȡ���ݾ���״̬ */
        lsm6dsv16x_flag_data_ready_get(&atk_ms6dsv, &drdy);
        
        /* ���ٶ����ݾ��� */
        if (drdy.drdy_xl)
        {
            lsm6dsv16x_acceleration_raw_get(&atk_ms6dsv, data_raw_acceleration);
            acceleration_mg[0] = lsm6dsv16x_from_fs2_to_mg(data_raw_acceleration[0]);
            acceleration_mg[1] = lsm6dsv16x_from_fs2_to_mg(data_raw_acceleration[1]);
            acceleration_mg[2] = lsm6dsv16x_from_fs2_to_mg(data_raw_acceleration[2]);
        }
        
        /* ���ٶ����ݾ��� */
        if (drdy.drdy_gy)
        {
            lsm6dsv16x_angular_rate_raw_get(&atk_ms6dsv, data_raw_angular_rate);
            angular_rate_mdps[0] = lsm6dsv16x_from_fs2000_to_mdps(data_raw_angular_rate[0]);
            angular_rate_mdps[1] = lsm6dsv16x_from_fs2000_to_mdps(data_raw_angular_rate[1]);
            angular_rate_mdps[2] = lsm6dsv16x_from_fs2000_to_mdps(data_raw_angular_rate[2]);
        }
        
        /* �¶����ݾ��� */
        if (drdy.drdy_temp)
        {
            lsm6dsv16x_temperature_raw_get(&atk_ms6dsv, &data_raw_temperature);
            temperature_degc = lsm6dsv16x_from_lsb_to_celsius(data_raw_temperature);
        }
        
        if (++times == 20)
        {
            times = 0;
            printf("\r\n******************************************\r\n");
            printf("Acceleration[mg]: %4.2f %4.2f %4.2f\r\n", acceleration_mg[0], acceleration_mg[1], acceleration_mg[2]);
            printf("Angular rate[mdps]: %4.2f %4.2f %4.2f\r\n", angular_rate_mdps[0], angular_rate_mdps[1], angular_rate_mdps[2]);
            printf("Temperature[degC]: %6.2f\r\n", temperature_degc);
        }
        
        delay_ms(10);
    }
#endif /* DEMO_READ_DATA_POLLING */
#ifdef DEMO_READ_DATA_FIFO_POLLING
    /* ���ü��ٶȼƺ������ǵ�ODR */
    lsm6dsv16x_xl_data_rate_set(&atk_ms6dsv, LSM6DSV16X_ODR_AT_60Hz);
    lsm6dsv16x_gy_data_rate_set(&atk_ms6dsv, LSM6DSV16X_ODR_AT_60Hz);
    
    /* ���ü��ٶȼƺ������ǵ����� */
    lsm6dsv16x_xl_full_scale_set(&atk_ms6dsv, LSM6DSV16X_2g);
    lsm6dsv16x_gy_full_scale_set(&atk_ms6dsv, LSM6DSV16X_2000dps);
    
    /* ʹ��ʱ��������� */
    lsm6dsv16x_timestamp_set(&atk_ms6dsv, PROPERTY_ENABLE);
    
    /* ����FIFO��ֵ */
    lsm6dsv16x_fifo_watermark_set(&atk_ms6dsv, 64);
    
    /* ����FIFO�Ĵ����������������� */
    lsm6dsv16x_fifo_xl_batch_set(&atk_ms6dsv, LSM6DSV16X_XL_BATCHED_AT_60Hz);
    lsm6dsv16x_fifo_gy_batch_set(&atk_ms6dsv, LSM6DSV16X_GY_BATCHED_AT_60Hz);
    lsm6dsv16x_fifo_timestamp_batch_set(&atk_ms6dsv, LSM6DSV16X_TMSTMP_DEC_8);
    
    /* ����FIFOģʽ */
    lsm6dsv16x_fifo_mode_set(&atk_ms6dsv, LSM6DSV16X_STREAM_MODE);
    
    while (1)
    {
        /* ��ȡFIFO״̬ */
        lsm6dsv16x_fifo_status_get(&atk_ms6dsv, &fifo_status);
        
        /* FIFO�� */
        if (fifo_status.fifo_th)
        {
            /* ��ȡFIFO�е����� */
            lsm6dsv16x_fifo_out_raw_get(&atk_ms6dsv, &data_raw_fifo);
            datax = (int16_t *)&data_raw_fifo.data[0];
            datay = (int16_t *)&data_raw_fifo.data[2];
            dataz = (int16_t *)&data_raw_fifo.data[4];
            ts = (int32_t *)&data_raw_fifo.data[0];
            
            switch (data_raw_fifo.tag)
            {
                /* ���ٶ����� */
                case LSM6DSV16X_XL_NC_TAG:
                {
                    acceleration_mg[0] = lsm6dsv16x_from_fs2_to_mg(*datax);
                    acceleration_mg[1] = lsm6dsv16x_from_fs2_to_mg(*datay);
                    acceleration_mg[2] = lsm6dsv16x_from_fs2_to_mg(*dataz);
                    break;
                }
                /* ���ٶ����� */
                case LSM6DSV16X_GY_NC_TAG:
                {
                    angular_rate_mdps[0] = lsm6dsv16x_from_fs2000_to_mdps(*datax);
                    angular_rate_mdps[1] = lsm6dsv16x_from_fs2000_to_mdps(*datay);
                    angular_rate_mdps[2] = lsm6dsv16x_from_fs2000_to_mdps(*dataz);
                    break;
                }
                /* ʱ������� */
                case LSM6DSV16X_TIMESTAMP_TAG:
                {
                    timestamp = *ts;
                    break;
                }
                default:
                {
                    break;
                }
          }
        }
        
        if (++times == 20)
        {
            times = 0;
            printf("\r\n******************************************\r\n");
            printf("Acceleration[mg]: %4.2f %4.2f %4.2f\r\n", acceleration_mg[0], acceleration_mg[1], acceleration_mg[2]);
            printf("Angular rate[mdps]: %4.2f %4.2f %4.2f\r\n", angular_rate_mdps[0], angular_rate_mdps[1], angular_rate_mdps[2]);
            printf("Timestamp[ms]: %d\r\n", timestamp);
        }
        
        delay_ms(10);
    }
#endif /* DEMO_READ_DATA_FIFO_POLLING */
#ifdef DEMO_QVAR_READ_DATA_POLLING
    /* ���ü��ٶȼƵ�ODR */
    lsm6dsv16x_xl_data_rate_set(&atk_ms6dsv, LSM6DSV16X_ODR_AT_15Hz);
    
    /* ���ü��ٶȼƵ����� */
    lsm6dsv16x_xl_full_scale_set(&atk_ms6dsv, LSM6DSV16X_2g);
    
    /* �����˲��� */
    filt_settling_mask.drdy = PROPERTY_ENABLE;
    filt_settling_mask.irq_xl = PROPERTY_ENABLE;
    filt_settling_mask.irq_g = PROPERTY_ENABLE;
    lsm6dsv16x_filt_settling_mask_set(&atk_ms6dsv, filt_settling_mask);
    lsm6dsv16x_filt_xl_lp2_set(&atk_ms6dsv, PROPERTY_ENABLE);
    lsm6dsv16x_filt_xl_lp2_bandwidth_set(&atk_ms6dsv, LSM6DSV16X_XL_STRONG);
    
    /* ʹ�ܾ��紫���� */
    qvar_mode.ah_qvar_en = 1;
    lsm6dsv16x_ah_qvar_mode_set(&atk_ms6dsv, qvar_mode);
    
    while (1)
    {
        /* ��ȡ״̬ */
        lsm6dsv16x_all_sources_get(&atk_ms6dsv, &all_sources);
        
        /* �����ѹ���ݾ��� */
        if (all_sources.drdy_ah_qvar)
        {
            /* ��ȡ�����ѹ���� */
            lsm6dsv16x_ah_qvar_raw_get(&atk_ms6dsv, &data_raw_qvar);
            qvar_mv = lsm6dsv16x_from_lsb_to_mv(data_raw_qvar);
        }
        
        if (++times == 20)
        {
            times = 0;
            printf("\r\n******************************************\r\n");
            printf("QVAR[mV]: %6.2f\r\n", qvar_mv);
        }
        
        delay_ms(10);
    }
#endif /* DEMO_QVAR_READ_DATA_POLLING */
#ifdef DEMO_READ_DATA_INT
    /* �����ж�·�� */
    pin_int.drdy_xl = PROPERTY_ENABLE;
    lsm6dsv16x_pin_int2_route_set(&atk_ms6dsv, &pin_int);
    
    /* ���ü��ٶȼƵ�ODR */
    lsm6dsv16x_xl_data_rate_set(&atk_ms6dsv, LSM6DSV16X_ODR_AT_120Hz);
    
    /* ���ü��ٶȼƵ����� */
    lsm6dsv16x_xl_full_scale_set(&atk_ms6dsv, LSM6DSV16X_2g);
    
    /* �����˲��� */
    filt_settling_mask.drdy = PROPERTY_ENABLE;
    filt_settling_mask.irq_xl = PROPERTY_ENABLE;
    filt_settling_mask.irq_g = PROPERTY_ENABLE;
    lsm6dsv16x_filt_settling_mask_set(&atk_ms6dsv, filt_settling_mask);
    lsm6dsv16x_filt_xl_lp2_set(&atk_ms6dsv, PROPERTY_ENABLE);
    lsm6dsv16x_filt_xl_lp2_bandwidth_set(&atk_ms6dsv, LSM6DSV16X_XL_STRONG);
    
    while (1)
    {
        /* ��ȡ�ж�״̬ */
        if (ATK_MS6DSV_READ_INT())
        {
            /* ��ȡ���ݾ���״̬ */
            lsm6dsv16x_flag_data_ready_get(&atk_ms6dsv, &drdy);
            
            if (drdy.drdy_xl)
            {
                lsm6dsv16x_acceleration_raw_get(&atk_ms6dsv, data_raw_acceleration);
                acceleration_mg[0] = lsm6dsv16x_from_fs2_to_mg(data_raw_acceleration[0]);
                acceleration_mg[1] = lsm6dsv16x_from_fs2_to_mg(data_raw_acceleration[1]);
                acceleration_mg[2] = lsm6dsv16x_from_fs2_to_mg(data_raw_acceleration[2]);
            }
            
            if (++times == 24)
            {
                times = 0;
                printf("\r\n******************************************\r\n");
                printf("Acceleration[mg]: %4.2f %4.2f %4.2f\r\n", acceleration_mg[0], acceleration_mg[1], acceleration_mg[2]);
            }
        }
    }
#endif /* DEMO_READ_DATA_INT */
#ifdef DEMO_READ_DATA_FIFO_INT
    /* �����ж�·�� */
    pin_int.fifo_th = PROPERTY_ENABLE;
    lsm6dsv16x_pin_int2_route_set(&atk_ms6dsv, &pin_int);
    
    /* ���ü��ٶȼƵ�ODR */
    lsm6dsv16x_xl_data_rate_set(&atk_ms6dsv, LSM6DSV16X_ODR_AT_60Hz);
    
    /* ���ü��ٶȼƵ����� */
    lsm6dsv16x_xl_full_scale_set(&atk_ms6dsv, LSM6DSV16X_2g);
    
    /* ʹ��ʱ��������� */
    lsm6dsv16x_timestamp_set(&atk_ms6dsv, PROPERTY_ENABLE);
    
    /* ����FIFO��ֵ */
    lsm6dsv16x_fifo_watermark_set(&atk_ms6dsv, 64);
    
    /* ����FIFO�Ĵ����������������� */
    lsm6dsv16x_fifo_xl_batch_set(&atk_ms6dsv, LSM6DSV16X_XL_BATCHED_AT_60Hz);
    lsm6dsv16x_fifo_timestamp_batch_set(&atk_ms6dsv, LSM6DSV16X_TMSTMP_DEC_32);
    
    /* ����FIFOģʽ */
    lsm6dsv16x_fifo_mode_set(&atk_ms6dsv, LSM6DSV16X_STREAM_MODE);
    
    while (1)
    {
        /* ��ȡ�ж�״̬ */
        if (ATK_MS6DSV_READ_INT())
        {
            /* ��ȡFIFO״̬ */
            lsm6dsv16x_fifo_status_get(&atk_ms6dsv, &fifo_status);
            
            num = fifo_status.fifo_level;
            while (num--)
            {
                /* ��ȡFIFO�е����� */
                lsm6dsv16x_fifo_out_raw_get(&atk_ms6dsv, &data_raw_fifo);
                datax = (int16_t *)&data_raw_fifo.data[0];
                datay = (int16_t *)&data_raw_fifo.data[2];
                dataz = (int16_t *)&data_raw_fifo.data[4];
                ts = (int32_t *)&data_raw_fifo.data[0];
                
                switch (data_raw_fifo.tag)
                {
                    /* ���ٶ����� */
                    case LSM6DSV16X_XL_NC_TAG:
                    {
                        acceleration_mg[0] = lsm6dsv16x_from_fs2_to_mg(*datax);
                        acceleration_mg[1] = lsm6dsv16x_from_fs2_to_mg(*datay);
                        acceleration_mg[2] = lsm6dsv16x_from_fs2_to_mg(*dataz);
                        break;
                    }
                    /* ʱ������� */
                    case LSM6DSV16X_TIMESTAMP_TAG:
                    {
                        timestamp = *ts;
                        break;
                    }
                    default:
                    {
                        break;
                    }
                }
            }
        }
        
        if (++times == 20)
        {
            times = 0;
            printf("\r\n******************************************\r\n");
            printf("Acceleration[mg]: %4.2f %4.2f %4.2f\r\n", acceleration_mg[0], acceleration_mg[1], acceleration_mg[2]);
            printf("Timestamp[ms]: %d\r\n", timestamp);
        }
        
        delay_ms(10);
    }
#endif /* DEMO_READ_DATA_FIFO_INT */
#ifdef DEMO_FREE_FALL
    /* �����ж�·�� */
    pin_int.freefall = PROPERTY_ENABLE;
    lsm6dsv16x_pin_int2_route_set(&atk_ms6dsv, &pin_int);
    
    /* ���ü��ٶȼƵ�ODR */
    lsm6dsv16x_xl_data_rate_set(&atk_ms6dsv, LSM6DSV16X_ODR_AT_120Hz);
    
    /* ���ü��ٶȼƵ����� */
    lsm6dsv16x_xl_full_scale_set(&atk_ms6dsv, LSM6DSV16X_2g);
    
    /* ʹ���ж� */
    irq.enable = PROPERTY_ENABLE;
    irq.lir = PROPERTY_ENABLE;
    lsm6dsv16x_interrupt_enable_set(&atk_ms6dsv, irq);
    
    /* ����������������� */
    lsm6dsv16x_ff_time_windows_set(&atk_ms6dsv, 0);
    lsm6dsv16x_ff_thresholds_set(&atk_ms6dsv, LSM6DSV16X_312_mg);
    
    while (1)
    {
        /* ��ȡ�ж�״̬ */
        if (ATK_MS6DSV_READ_INT())
        {
            /* ��ȡ״̬ */
            lsm6dsv16x_all_sources_get(&atk_ms6dsv, &status);
            
            /* ���������¼� */
            if (status.free_fall)
            {
                printf("Free Fall event!\r\n");
            }
        }
    }
#endif /* DEMO_FREE_FALL */
#ifdef DEMO_WAKEUP
    /* �����ж�·�� */
    pin_int.wakeup = PROPERTY_ENABLE;
    lsm6dsv16x_pin_int2_route_set(&atk_ms6dsv, &pin_int);
    
    /* ���ü��ٶȼƵ�ODR */
    lsm6dsv16x_xl_data_rate_set(&atk_ms6dsv, LSM6DSV16X_ODR_AT_480Hz);
    
    /* ���ü��ٶȼƵ����� */
    lsm6dsv16x_xl_full_scale_set(&atk_ms6dsv, LSM6DSV16X_2g);
    
    /* ʹ���ж� */
    irq.enable = PROPERTY_ENABLE;
    irq.lir = PROPERTY_ENABLE;
    lsm6dsv16x_interrupt_enable_set(&atk_ms6dsv, irq);
    
    /* �����˲��� */
    lsm6dsv16x_filt_xl_fast_settling_set(&atk_ms6dsv, 1);
    lsm6dsv16x_mask_trigger_xl_settl_set(&atk_ms6dsv, 1);
    lsm6dsv16x_filt_wkup_act_feed_set(&atk_ms6dsv, LSM6DSV16X_WK_FEED_HIGH_PASS);
    
    /* ���û��Ѽ����� */
    wu.inactivity_cfg.inact_dur = 0;
    wu.inactivity_cfg.xl_inact_odr = 1;
    wu.inactivity_cfg.wu_inact_ths_w = 3;
    wu.inactivity_ths = 0;
    wu.threshold = 1;
    wu.duration = 0;
    lsm6dsv16x_act_thresholds_set(&atk_ms6dsv, &wu);
    
    while (1)
    {
        /* ��ȡ�ж�״̬ */
        if (ATK_MS6DSV_READ_INT())
        {
            /* ��ȡ״̬ */
            lsm6dsv16x_all_sources_get(&atk_ms6dsv, &status);
            
            /* �����¼� */
            if (status.wake_up)
            {
                printf("Wakeup event!\r\n");
            }
        }
    }
#endif /* DEMO_WAKEUP */
#ifdef DEMO_6D
    /* �����ж�·�� */
    pin_int.sixd = PROPERTY_ENABLE;
    lsm6dsv16x_pin_int2_route_set(&atk_ms6dsv, &pin_int);
    
    /* ���ü��ٶȼƵ�ODR */
    lsm6dsv16x_xl_data_rate_set(&atk_ms6dsv, LSM6DSV16X_ODR_AT_120Hz);
    
    /* ���ü��ٶȼƵ����� */
    lsm6dsv16x_xl_full_scale_set(&atk_ms6dsv, LSM6DSV16X_2g);
    
    /* ʹ���ж� */
    irq.enable = PROPERTY_ENABLE;
    irq.lir = PROPERTY_ENABLE;
    lsm6dsv16x_interrupt_enable_set(&atk_ms6dsv, irq);
    
    /* �����˲��� */
    lsm6dsv16x_filt_sixd_feed_set(&atk_ms6dsv, LSM6DSV16X_SIXD_FEED_LOW_PASS);
    
    /* ����6D��������� */
    lsm6dsv16x_6d_threshold_set(&atk_ms6dsv, LSM6DSV16X_DEG_60);
    
    while (1)
    {
        /* ��ȡ�ж�״̬ */
        if (ATK_MS6DSV_READ_INT())
        {
            /* ��ȡ״̬ */
            lsm6dsv16x_all_sources_get(&atk_ms6dsv, &status);
            
            /* 6D�¼� */
            if (status.six_d)
            {
                sixd_event = (status.six_d << 6) |
                             (status.six_d_zh << 5) |
                             (status.six_d_zl << 4) |
                             (status.six_d_yh << 3) |
                             (status.six_d_yl << 2) |
                             (status.six_d_xh << 1) |
                             (status.six_d_xl << 0);
                switch (sixd_event)
                {
                    case 0x48:
                    {
                        printf("6D Position A!\r\n");
                        break;
                    }
                    case 0x41:
                    {
                        printf("6D Position B!\r\n");
                        break;
                    }
                    case 0x42:
                    {
                        printf("6D Position C!\r\n");
                        break;
                    }
                    case 0x44:
                    {
                        printf("6D Position D!\r\n");
                        break;
                    }
                    case 0x60:
                    {
                        printf("6D Position E!\r\n");
                        break;
                    }
                    case 0x50:
                    {
                        printf("6D Position F!\r\n");
                        break;
                    }
                    default:
                    {
                        break;
                    }
                }
            }
        }
    }
#endif /* DEMO_6D */
#ifdef DEMO_TAP
    /* �����ж�·�� */
    pin_int.double_tap = PROPERTY_ENABLE;
    pin_int.single_tap = PROPERTY_ENABLE;
    lsm6dsv16x_pin_int2_route_set(&atk_ms6dsv, &pin_int);
    
    /* ���ü��ٶȼƵ�ODR */
    lsm6dsv16x_xl_data_rate_set(&atk_ms6dsv, LSM6DSV16X_ODR_AT_480Hz);
    
    /* ���ü��ٶȼƵ����� */
    lsm6dsv16x_xl_full_scale_set(&atk_ms6dsv, LSM6DSV16X_8g);
    
    /* ʹ���ж� */
    irq.enable = PROPERTY_ENABLE;
    irq.lir = PROPERTY_DISABLE;
    lsm6dsv16x_interrupt_enable_set(&atk_ms6dsv, irq);
    
    /* ���õ���˫�������� */
    tap.tap_z_en = PROPERTY_ENABLE;
    lsm6dsv16x_tap_detection_set(&atk_ms6dsv, tap);
    tap_ths.z = 3;
    lsm6dsv16x_tap_thresholds_set(&atk_ms6dsv, tap_ths);
    tap_win.tap_gap = 7;
    tap_win.shock = 3;
    tap_win.quiet = 3;
    lsm6dsv16x_tap_time_windows_set(&atk_ms6dsv, tap_win);
    lsm6dsv16x_tap_mode_set(&atk_ms6dsv, LSM6DSV16X_BOTH_SINGLE_DOUBLE);
    
    while (1)
    {
        /* ��ȡ�ж�״̬ */
        if (ATK_MS6DSV_READ_INT())
        {
            /* ��ȡ״̬ */
            lsm6dsv16x_all_sources_get(&atk_ms6dsv, &status);
            
            /* �����¼� */
            if (status.single_tap)
            {
                printf("Single TAP!\r\n");
            }
            
            /* ˫���¼� */
            if (status.double_tap)
            {
                printf("Double TAP!\r\n");
            }
        }
    }
#endif /* DEMO_TAP */
#ifdef DEMO_STEP_COUNTER
    /* ���ü��ٶȼƺ������ǵ�ODR */
    lsm6dsv16x_xl_data_rate_set(&atk_ms6dsv, LSM6DSV16X_ODR_AT_30Hz);
    lsm6dsv16x_gy_data_rate_set(&atk_ms6dsv, LSM6DSV16X_ODR_OFF);
    
    /* ���ü��ٶȼƺ������ǵ����� */
    lsm6dsv16x_xl_full_scale_set(&atk_ms6dsv, LSM6DSV16X_4g);
    lsm6dsv16x_gy_full_scale_set(&atk_ms6dsv, LSM6DSV16X_2000dps);
    
    /* �����˲��� */
    filt_settling_mask.drdy = PROPERTY_ENABLE;
    filt_settling_mask.irq_xl = PROPERTY_ENABLE;
    filt_settling_mask.irq_g = PROPERTY_ENABLE;
    lsm6dsv16x_filt_settling_mask_set(&atk_ms6dsv, filt_settling_mask);
    lsm6dsv16x_filt_gy_lp1_set(&atk_ms6dsv, PROPERTY_ENABLE);
    lsm6dsv16x_filt_gy_lp1_bandwidth_set(&atk_ms6dsv, LSM6DSV16X_GY_ULTRA_LIGHT);
    lsm6dsv16x_filt_xl_lp2_set(&atk_ms6dsv, PROPERTY_ENABLE);
    lsm6dsv16x_filt_xl_lp2_bandwidth_set(&atk_ms6dsv, LSM6DSV16X_XL_STRONG);
    
    /* ���ò��������� */
    stpcnt_mode.step_counter_enable = PROPERTY_ENABLE;
    stpcnt_mode.false_step_rej = PROPERTY_ENABLE;
    lsm6dsv16x_stpcnt_mode_set(&atk_ms6dsv, stpcnt_mode);
    lsm6dsv16x_stpcnt_rst_step_set(&atk_ms6dsv, PROPERTY_ENABLE);
    
    while (1)
    {
        /* ��ȡ״̬ */
        lsm6dsv16x_all_sources_get(&atk_ms6dsv, &status);
        
        /* ��������¼� */
        if (status.step_detector)
        {
            lsm6dsv16x_stpcnt_steps_get(&atk_ms6dsv, &steps);
            printf("Steps: %d\r\n", steps);
        }
    }
#endif /* DEMO_STEP_COUNTER */
#ifdef DEMO_SENSOR_FUSION
    /* ���ü��ٶȼƺ������ǵ�ODR */
    lsm6dsv16x_xl_data_rate_set(&atk_ms6dsv, LSM6DSV16X_ODR_AT_30Hz);
    lsm6dsv16x_gy_data_rate_set(&atk_ms6dsv, LSM6DSV16X_ODR_AT_30Hz);
    
    /* ���ü��ٶȼƺ������ǵ����� */
    lsm6dsv16x_xl_full_scale_set(&atk_ms6dsv, LSM6DSV16X_4g);
    lsm6dsv16x_gy_full_scale_set(&atk_ms6dsv, LSM6DSV16X_2000dps);
    
    /* ����FIFO��ֵ */
    lsm6dsv16x_fifo_watermark_set(&atk_ms6dsv, 32);
    
    /* ����FIFO�Ĵ������ں����������� */
    fifo_sflp.game_rotation = PROPERTY_ENABLE;
    fifo_sflp.gravity = PROPERTY_ENABLE;
    fifo_sflp.gbias = PROPERTY_ENABLE;
    lsm6dsv16x_fifo_sflp_batch_set(&atk_ms6dsv, fifo_sflp);
    
    /* ����FIFOģʽ */
    lsm6dsv16x_fifo_mode_set(&atk_ms6dsv, LSM6DSV16X_STREAM_MODE);
    
    /* ���ô������ںϲ��� */
    lsm6dsv16x_sflp_data_rate_set(&atk_ms6dsv, LSM6DSV16X_SFLP_30Hz);
    lsm6dsv16x_sflp_game_rotation_set(&atk_ms6dsv, PROPERTY_ENABLE);
    gbias.gbias_x = 0.0f;
    gbias.gbias_y = 0.0f;
    gbias.gbias_z = 0.0f;
    lsm6dsv16x_sflp_game_gbias_set(&atk_ms6dsv, &gbias);
    
    while (1)
    {
        /* ��ȡFIFO״̬ */
        lsm6dsv16x_fifo_status_get(&atk_ms6dsv, &fifo_status);
        
        num = fifo_status.fifo_level;
        while (num--)
        {
            /* ��ȡFIFO�е����� */
            lsm6dsv16x_fifo_out_raw_get(&atk_ms6dsv, &data_raw_fifo);
            
            switch (data_raw_fifo.tag)
            {
                /* ������ƫ�� */
                case LSM6DSV16X_SFLP_GYROSCOPE_BIAS_TAG:
                {
                    axis = (int16_t *)&data_raw_fifo.data[0];
                    gbias_mdps[0] = lsm6dsv16x_from_fs125_to_mdps(axis[0]);
                    gbias_mdps[1] = lsm6dsv16x_from_fs125_to_mdps(axis[1]);
                    gbias_mdps[2] = lsm6dsv16x_from_fs125_to_mdps(axis[2]);
                    break;
                }
                /* �������� */
                case LSM6DSV16X_SFLP_GRAVITY_VECTOR_TAG:
                {
                    axis = (int16_t *)&data_raw_fifo.data[0];
                    gravity_mg[0] = lsm6dsv16x_from_sflp_to_mg(axis[0]);
                    gravity_mg[1] = lsm6dsv16x_from_sflp_to_mg(axis[1]);
                    gravity_mg[2] = lsm6dsv16x_from_sflp_to_mg(axis[2]);
                    break;
                }
                /* ��Ϸ��תʸ�� */
                case LSM6DSV16X_SFLP_GAME_ROTATION_VECTOR_TAG:
                {
                    sflp2q(quat, (uint16_t *)&data_raw_fifo.data[0]);
                    break;
                }
                default:
                {
                    break;
                }
            }
        }
        
        if (++times == 20)
        {
            times = 0;
            printf("\r\n******************************************\r\n");
            printf("GBIAS[mdps]: %4.2f %4.2f %4.2f\r\n", gbias_mdps[0], gbias_mdps[1], gbias_mdps[2]);
            printf("Gravity[mg]: %4.2f %4.2f %4.2f\r\n", gravity_mg[0], gravity_mg[1], gravity_mg[2]);
            printf("Game Rotation: %2.3f %2.3f %2.3f %2.3f\r\n", quat[0], quat[1], quat[2], quat[3]);
        }
        
        delay_ms(10);
    }
#endif /* DEMO_SENSOR_FUSION */
#ifdef DEMO_SENSOR_FUSION_ANOTC
    /* ���ü��ٶȼƺ������ǵ�ODR */
    lsm6dsv16x_xl_data_rate_set(&atk_ms6dsv, LSM6DSV16X_ODR_AT_15Hz);
    lsm6dsv16x_gy_data_rate_set(&atk_ms6dsv, LSM6DSV16X_ODR_AT_15Hz);
    
    /* ���ü��ٶȼƺ������ǵ����� */
    lsm6dsv16x_xl_full_scale_set(&atk_ms6dsv, LSM6DSV16X_2g);
    lsm6dsv16x_gy_full_scale_set(&atk_ms6dsv, LSM6DSV16X_125dps);
    
    /* ������������ƫֵ */
    {
        for (times = 0; times < 200;)
        {
            lsm6dsv16x_flag_data_ready_get(&atk_ms6dsv, &drdy);
            
            if (drdy.drdy_gy)
            {
                lsm6dsv16x_angular_rate_raw_get(&atk_ms6dsv, data_raw_angular_rate);
                angular_rate_mdps_avg[0] += lsm6dsv16x_from_fs125_to_mdps(data_raw_angular_rate[0]);
                angular_rate_mdps_avg[1] += lsm6dsv16x_from_fs125_to_mdps(data_raw_angular_rate[1]);
                angular_rate_mdps_avg[2] += lsm6dsv16x_from_fs125_to_mdps(data_raw_angular_rate[2]);
                times++;
            }
        }
        angular_rate_mdps_avg[0] /= 200;
        angular_rate_mdps_avg[1] /= 200;
        angular_rate_mdps_avg[2] /= 200;
    }
    
    /* ����FIFO��ֵ */
    lsm6dsv16x_fifo_watermark_set(&atk_ms6dsv, 32);
    
    /* ����FIFO�Ĵ������ں����������� */
    fifo_sflp.game_rotation = PROPERTY_ENABLE;
    lsm6dsv16x_fifo_sflp_batch_set(&atk_ms6dsv, fifo_sflp);
    
    /* ����FIFOģʽ */
    lsm6dsv16x_fifo_mode_set(&atk_ms6dsv, LSM6DSV16X_STREAM_MODE);
    
    /* ���ô������ںϲ��� */
    lsm6dsv16x_sflp_game_rotation_set(&atk_ms6dsv, PROPERTY_DISABLE);
    lsm6dsv16x_sflp_data_rate_set(&atk_ms6dsv, LSM6DSV16X_SFLP_15Hz);
    lsm6dsv16x_sflp_game_rotation_set(&atk_ms6dsv, PROPERTY_ENABLE);
    gbias.gbias_x = angular_rate_mdps_avg[0] / 1000.0;
    gbias.gbias_y = angular_rate_mdps_avg[1] / 1000.0;
    gbias.gbias_z = angular_rate_mdps_avg[2] / 1000.0;
    lsm6dsv16x_sflp_game_gbias_set(&atk_ms6dsv, &gbias);
    
    while (1)
    {
        /* ��ȡFIFO״̬ */
        lsm6dsv16x_fifo_status_get(&atk_ms6dsv, &fifo_status);
        
        num = fifo_status.fifo_level;
        while (num--)
        {
            /* ��ȡFIFO�е����� */
            lsm6dsv16x_fifo_out_raw_get(&atk_ms6dsv, &data_raw_fifo);
            
            switch (data_raw_fifo.tag)
            {
                /* ��Ϸ��תʸ�� */
                case LSM6DSV16X_SFLP_GAME_ROTATION_VECTOR_TAG:
                {
                    sflp2q(quat, (uint16_t *)&data_raw_fifo.data[0]);
                    pitch = atan2(2 * (quat[0] * quat[3] + quat[1] * quat[2]), 1 - 2 * (quat[2] * quat[2] + quat[3] * quat[3])) * 57.3;
                    if (pitch > 0)
                    {
                        pitch = 180 - pitch;
                    }
                    else
                    {
                        pitch = -pitch - 180;
                    }
                    roll = -asin(2 * (quat[0] * quat[2] - quat[3] * quat[1])) * 57.3;
                    yaw = -atan2(2 * (quat[0] * quat[1] + quat[2] * quat[3]), 1 - 2 * (quat[1] * quat[1] + quat[2] * quat[2])) * 57.3;
                    demo_niming_report_status((int16_t)(roll * 100), (int16_t)((pitch) * 100), (int16_t)(yaw * 100), 0, 0, 0);
                    break;
                }
                default:
                {
                    break;
                }
            }
        }
    }
#endif /* DEMO_SENSOR_FUSION_ANOTC */
#ifdef DEMO_FSM_TOUCH
    /* ���ü��ٶȼƵ�ODR */
    lsm6dsv16x_xl_data_rate_set(&atk_ms6dsv, LSM6DSV16X_ODR_AT_15Hz);
    
    /* ���ü��ٶȼƵ����� */
    lsm6dsv16x_xl_full_scale_set(&atk_ms6dsv, LSM6DSV16X_2g);
    
    /* �����˲��� */
    filt_settling_mask.drdy = PROPERTY_ENABLE;
    filt_settling_mask.irq_xl = PROPERTY_ENABLE;
    filt_settling_mask.irq_g = PROPERTY_ENABLE;
    lsm6dsv16x_filt_settling_mask_set(&atk_ms6dsv, filt_settling_mask);
    lsm6dsv16x_filt_xl_lp2_set(&atk_ms6dsv, PROPERTY_ENABLE);
    lsm6dsv16x_filt_xl_lp2_bandwidth_set(&atk_ms6dsv, LSM6DSV16X_XL_STRONG);
    
    /* ʹ�ܾ��紫���� */
    qvar_mode.ah_qvar_en = 1;
    lsm6dsv16x_ah_qvar_mode_set(&atk_ms6dsv, qvar_mode);
    
    /* ����״̬�� */
    for (reg_index = 0; reg_index < (sizeof(lsm6dsv16x_fsm_touch) / sizeof(ucf_line_t)); reg_index++)
    {
        lsm6dsv16x_write_reg(&atk_ms6dsv, lsm6dsv16x_fsm_touch[reg_index].address, (uint8_t *)&lsm6dsv16x_fsm_touch[reg_index].data, 1);
    }
    
    while (1)
    {
        /* ��ȡ״̬��״̬ */
        lsm6dsv16x_read_reg(&atk_ms6dsv, LSM6DSV16X_FSM_STATUS_MAINPAGE, (uint8_t *)&fsm_status, 1);
        
        if (fsm_status.is_fsm1 || fsm_status.is_fsm2 || fsm_status.is_fsm3 || fsm_status.is_fsm4)
        {
            /* �����¼� */
            if (fsm_status.is_fsm4)
            {
                printf("Long Touch!\r\n");
            }
            /* �������¼� */
            if (fsm_status.is_fsm3)
            {
                printf("Triple Touch!\r\n");
            }
            /* ˫���¼� */
            else if (fsm_status.is_fsm2)
            {
                printf("Double Touch!\r\n");
            }
            /* �����¼� */
            else if (fsm_status.is_fsm1)
            {
                printf("Single Touch!\r\n");
            }
            
            HAL_Delay(100);
        }
    }
#endif /* DEMO_FSM_TOUCH */
#ifdef DEMO_FSM_4D
    /* ���ü��ٶȼƺ������ǵ�ODR */
    lsm6dsv16x_xl_data_rate_set(&atk_ms6dsv, LSM6DSV16X_ODR_AT_7Hz5);
    lsm6dsv16x_gy_data_rate_set(&atk_ms6dsv, LSM6DSV16X_ODR_AT_15Hz);
    
    /* ���ü��ٶȼƺ������ǵ����� */
    lsm6dsv16x_xl_full_scale_set(&atk_ms6dsv, LSM6DSV16X_2g);
    lsm6dsv16x_gy_full_scale_set(&atk_ms6dsv, LSM6DSV16X_2000dps);
    
    /* �����˲��� */
    filt_settling_mask.drdy = PROPERTY_ENABLE;
    filt_settling_mask.irq_xl = PROPERTY_ENABLE;
    filt_settling_mask.irq_g = PROPERTY_ENABLE;
    lsm6dsv16x_filt_settling_mask_set(&atk_ms6dsv, filt_settling_mask);
    lsm6dsv16x_filt_gy_lp1_set(&atk_ms6dsv, PROPERTY_ENABLE);
    lsm6dsv16x_filt_gy_lp1_bandwidth_set(&atk_ms6dsv, LSM6DSV16X_GY_ULTRA_LIGHT);
    lsm6dsv16x_filt_xl_lp2_set(&atk_ms6dsv, PROPERTY_ENABLE);
    lsm6dsv16x_filt_xl_lp2_bandwidth_set(&atk_ms6dsv, LSM6DSV16X_XL_STRONG);
    
    /* ����״̬�� */
    for (reg_index = 0; reg_index < (sizeof(lsm6dsv16x_four_d) / sizeof(ucf_line_t)); reg_index++)
    {
        lsm6dsv16x_write_reg(&atk_ms6dsv, lsm6dsv16x_four_d[reg_index].address, (uint8_t *)&lsm6dsv16x_four_d[reg_index].data, 1);
    }
    
    while (1)
    {
        /* ��ȡ״̬��״̬ */
        lsm6dsv16x_read_reg(&atk_ms6dsv, LSM6DSV16X_FSM_STATUS_MAINPAGE, (uint8_t *)&fsm_status, 1);
        
        if (fsm_status.is_fsm1)
        {
            /* ��ȡ״̬��������� */
            lsm6dsv16x_fsm_out_get(&atk_ms6dsv, &fsm_out);
            switch(fsm_out.fsm_outs1)
            {
                /* Y�ᳯ���¼� */
                case 0x10:
                {
                    printf("Y down event!\r\n");
                    break;
                }
                /* Y�ᳯ���¼� */
                case 0x20:
                {
                    printf("Y up event!\r\n");
                    break;
                }
                /* X�ᳯ���¼� */
                case 0x40:
                {
                    printf("X down event!\r\n");
                    break;
                }
                /* X�ᳯ���¼� */
                case 0x80:
                {
                    printf("X up event!\r\n");
                    break;
                }
            }
            
            HAL_Delay(100);
        }
    }
#endif /* DEMO_FSM_4D */
}
